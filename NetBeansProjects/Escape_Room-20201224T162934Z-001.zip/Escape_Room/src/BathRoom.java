
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class BathRoom extends OurFrame {
    
    private JLabel NoteLabel, CraftLabel, KitchenRoomLabel;
    private ImageSet backgroundImg, NoteImg, CraftImg, DoorImg;
    private Hint NoteHint, CraftHint;
    
    public BathRoom(Player p) {
        super("bathroom", p);
        contentpane.setLayout(new BorderLayout());
        
        addcomponent();
        
    }
    
    @Override
    public void addcomponent() {
        backgroundImg = new ImageSet("resource/test.jpg").resize(1366, 618);
        NoteImg = new ImageSet("resource/piano.png");
        CraftImg = new ImageSet("resource/craft.png");
        DoorImg = new ImageSet("resource/back.png");
        
        drawpane = new JLabel();
        drawpane.setIcon(backgroundImg);
        drawpane.setLayout(null);
        
        NoteLabel = new JLabel(NoteImg);
        NoteLabel.setBounds(100, 100, 388, 300);
        
        CraftLabel = new JLabel(CraftImg);
        CraftLabel.setBounds(700, 200, 300, 300);
        
        KitchenRoomLabel = new JLabel(DoorImg);
        KitchenRoomLabel.setBounds(0, 0, 64, 64);
        
        drawpane.add(NoteLabel);
        drawpane.add(KitchenRoomLabel);
        drawpane.add(CraftLabel);
        
        addListener();
        addpuzzle();
        
        contentpane.add(drawpane, BorderLayout.CENTER);
        contentpane.add(player.getPane(), BorderLayout.PAGE_START);

        // updatePlayerpane();
    }

    public void addpuzzle() {
        
        NoteHint = new Hint("Note", player);
        CraftHint = new Hint("Craft", player);
    }

    public void addListener() {
        NoteLabel.addMouseListener(new MouseAdapter() {
            
            @Override
            public void mousePressed(MouseEvent e) {
                //pt.getItem(0).setIcon(null);
                // new Hint("Note", Bt).setVisible(true);

                setVisible(false);
                NoteHint.Open();
                
            }
            
        });
        CraftLabel.addMouseListener(new MouseAdapter() {
            
            @Override
            public void mousePressed(MouseEvent e) {
                //pt.getItem(0).setIcon(null);
                // new Hint("Note", Bt).setVisible(true);

                setVisible(false);
                CraftHint.Open();
            }
            
        });
        KitchenRoomLabel.addMouseListener(new MouseAdapter() {
            
            @Override
            public void mousePressed(MouseEvent e) {
                
                setVisible(false);
                player.getLivingRoom().Open();
                
            }
            
        });
        
    }
    
}

class Hint extends OurFrame {
    
    private ImageSet HintImg;
    private JLabel HintLabel, BackLabel;
    private String name;
    // private BathRoom Bt;

    public Hint(String n, Player p) {
        super("Hint", p);
        name = n;
        contentpane.setLayout(new BorderLayout());
        contentpane.setBackground(Color.DARK_GRAY);
        HintLabel = new JLabel(HintImg);
        
        addcomponent();
    }
    
    public void addcomponent() {
        
        drawpane = new JLabel();
        drawpane.setBackground(Color.DARK_GRAY);
        drawpane.setLayout(null);
        
        BackLabel = new JLabel(new ImageSet("resource/back.png"));
        BackLabel.setBounds(0, 0, 64, 64);
        
        if (name.equals("Note")) {
            System.out.println("hello");
            SetNoteImg();
        }
        if (name.equals("Craft")) {
            SetCraftImg();
        }
        
        addListener();
        drawpane.add(HintLabel);
        drawpane.add(BackLabel);        
        
        contentpane.add(drawpane, BorderLayout.CENTER);
        validate();
        
    }
    
    public void addListener() {
        
        BackLabel.addMouseListener(new MouseAdapter() {
            
            public void mousePressed(MouseEvent e) {
                setVisible(false);
                player.getBathRoom().Open();
                
            }
            
        });
        
    }
    
    public void SetNoteImg() {
        HintLabel.setIcon(new ImageSet("resource/piano.png"));
        HintLabel.setBounds(300, 300, 300, 300);
    }
    
    public void SetCraftImg() {
        HintLabel.setIcon(new ImageSet("resource/back.png").resize(300, 300));
        HintLabel.setBounds(300, 300, 300, 300);
        
    }
    
}
