
import java.awt.*;
import java.awt.event.*;
import java.util.Optional;
import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Nearu
 */
public class DoorExit extends OurFrame {

    private String Password = "", temp = "";
    private JLabel PasswordLabel, EnterLabel;
    private ImageSet EnterImg;

    public DoorExit(Player p) {
        super("DoorExit", p);
        contentpane.setLayout(new BorderLayout());
        contentpane.setBackground(Color.DARK_GRAY);
        addcomponent();
    }

    public void addcomponent() {

        EnterImg = new ImageSet("resource/tape.png");

        drawpane = new JLabel();
        drawpane.setLayout(null);

        Font f = new Font("SanSerif", Font.BOLD, 20);
        PasswordLabel = new JLabel();
        PasswordLabel.setForeground(Color.WHITE);
        PasswordLabel.setFont(f);
        PasswordLabel.setBounds(550, 200, 120, 30);

        EnterLabel = new JLabel(EnterImg);
        EnterLabel.setBounds(700, 200, 150, 200);

        addListener();

        drawpane.add(PasswordLabel);
        drawpane.add(EnterLabel);

        contentpane.add(drawpane, BorderLayout.CENTER);

    }

    public void CheckPassword() {
        if (!Password.isEmpty()) {
            if (Password.equals("12345")) {
                JOptionPane.showMessageDialog(null,
                        "You Win !!");

            } else {
                JOptionPane.showMessageDialog(null,
                        "Wrong password");
            }
        } else {
            JOptionPane.showMessageDialog(null,
                    "Enter Password");
        }

    }

    public void addListener() {
        EnterLabel.addMouseListener(new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent e) {
                CheckPassword();
            }

        });

        this.addKeyListener(new KeyAdapter() {

            public void keyPressed(KeyEvent e) {

                if (Password.length() < 5) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_NUMPAD0:
                            Password += 0;
                            break;
                        case KeyEvent.VK_NUMPAD1:
                            Password += 1;
                            break;
                        case KeyEvent.VK_NUMPAD2:
                            Password += 2;
                            break;
                        case KeyEvent.VK_NUMPAD3:
                            Password += 3;
                            break;
                        case KeyEvent.VK_NUMPAD4:
                            Password += 4;
                            break;
                        case KeyEvent.VK_NUMPAD5:
                            Password += 5;
                            break;
                        case KeyEvent.VK_NUMPAD6:
                            Password += 6;
                            break;
                        case KeyEvent.VK_NUMPAD7:
                            Password += 7;
                            break;
                        case KeyEvent.VK_NUMPAD8:
                            Password += 8;
                            break;
                        case KeyEvent.VK_NUMPAD9:
                            Password += 9;
                            break;
                    }
                    PasswordLabel.setText(Password);
                }
                //deleted Key

                if (e.getKeyChar() == KeyEvent.VK_DELETE) {
                    Password = Optional.ofNullable(Password)
                            .filter(s -> !s.isEmpty())
                            .map(s -> s.substring(0, s.length() - 1))
                            .orElse(Password);
                    PasswordLabel.setText(Password);
                }

            }

        });

    }

    public static void main(String args[]) {
        //new DoorExit("oor",Pl).setVisible(true);

    }

}
