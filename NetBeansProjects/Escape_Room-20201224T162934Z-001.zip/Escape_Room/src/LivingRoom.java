
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LivingRoom extends OurFrame {

    private ImageSet backgroundImg, MusicBoxImg, TVImg, PillowImg, DrawercloseImg, DraweropenImg, DoorExitImg,DoorImg;
    private JLabel MusicBoxLabel, TVLabel, PillowLabel, TabeLabel,
                   KitchenRoomLabel, DrawerLabel, WoodLabel, DoorExitLabel,BedRoomLabel;
    private boolean Tapelost, openDrawer;
    private int Xx, Yy;
    private Musicpuzzle Pianopuzzle;
    private TV TVpuzzle;
    private DoorExit Doorexit;

    public LivingRoom(Player p) {

        super("Living room", p);
        player = p;
        setIconImage(new ImageSet("resource/logo.png").getImage());
        contentpane.setLayout(new BorderLayout());

        Tapelost = false;

        addcomponent();

    }

    public void addcomponent() {
        //set up obj ต่างๆ ในห้อง

        //import รูปจากFile
        backgroundImg = new ImageSet("resource/test.jpg").resize(1366, 618);
        MusicBoxImg = new ImageSet("resource/piano.png");
        TVImg = new ImageSet("resource/TV.png").resize(300, 300);
        PillowImg = new ImageSet("resource/pillow.png");
        DrawercloseImg = new ImageSet("resource/Drawer_close.png").resize(150, 200);
        DraweropenImg = new ImageSet("resource/Drawer_open.png").resize(150, 200);
        DoorExitImg = new ImageSet("resource/Door.png").resize(150, 200);
        DoorImg  = new ImageSet("resource/back.png");
        
        drawpane = new JLabel();
        drawpane.setIcon(backgroundImg);
        drawpane.setLayout(null);

        KitchenRoomLabel = new JLabel(DoorImg);
        KitchenRoomLabel.setBounds(1280, 0, 64, 64);

        MusicBoxLabel = new JLabel(MusicBoxImg);
        MusicBoxLabel.setBounds(867, 392, 322, 86);

        TVLabel = new JLabel(TVImg);
        TVLabel.setBounds(638, 43, 300, 300);

        PillowLabel = new JLabel(PillowImg);
        PillowLabel.setBounds(100, 400, 298, 200);

        TabeLabel = new JLabel(new ImageSet("resource/tape.png"));
        TabeLabel.setBounds(100, 500, 175, 100);

        DrawerLabel = new JLabel(DrawercloseImg);
        DrawerLabel.setBounds(550, 350, 150, 200);

        WoodLabel = new JLabel(player.getItem(2).getImg());
        WoodLabel.setBounds(50, 25, 75, 100);

        DoorExitLabel = new JLabel(DoorExitImg);
        DoorExitLabel.setBounds(150, 100, 150, 200);
        
        BedRoomLabel = new JLabel(DoorImg);
        BedRoomLabel.setBounds(0, 0, 64, 64);
        
        addListener();
        addPuzzle();

        drawpane.add(MusicBoxLabel);
        drawpane.add(TVLabel);
        drawpane.add(PillowLabel);
        drawpane.add(TabeLabel);
        drawpane.add(KitchenRoomLabel);
        drawpane.add(DrawerLabel);
        drawpane.add(DoorExitLabel);
        drawpane.add(BedRoomLabel);
        
        contentpane.add(drawpane, BorderLayout.CENTER);
        //updatePlayerpane();
        //สร้าง panel สำหรับ player ข้างบน

    }
    public int getxx(){
        return Xx;
    }
    /*public void addItemListener(JLabel item ){
      
    JLabel test = new JLabel(new ImageSet("resource/back.png"));
    test.setBounds(0, 0,64, 64);
    test.setVisible(false);
    drawpane.add(test);
    item.addMouseListener( new MouseAdapter(){
     public void mousePressed(MouseEvent e) {
               
               test.setVisible(true);
                
                //test.setLocation(0, 0);
            }
    });
    test.addMouseListener( new MouseAdapter(){
     public void mousePressed(MouseEvent e) {
                 xi = e.getX();
                 yi = e.getY();
            }
    });
   test.addMouseMotionListener( new MouseMotionAdapter(){
    public void mouseDragged(MouseEvent e) {
                
                int x =  e.getXOnScreen();
                int y =  e.getYOnScreen();
                
                int SumX = x - xi - 64;
                int SumY = y - yi - 64;
                test.setBounds(SumX, SumY, 64, 64);
                 System.out.printf("x = %d  y = %d xi =  %d  yi =  %d\n",x,y,xi,yi);
              if(test.getBounds().intersects(PillowLabel.getBounds())){
               
                  drawpane.remove(test);
                  Playerpane.remove(item);
                  validate();
        }
  
            }
 
    });
    }*/
    public void addListener() {
        DrawerLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
                if (openDrawer) {
                    DrawerLabel.setIcon(DraweropenImg);
                    DrawerLabel.add(WoodLabel);
                    validate();
                    openDrawer = false;
                }
            }

        });
        WoodLabel.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                WoodLabel.setIcon(null);
                player.getItem(2).setIcon(null);
                DrawerLabel.remove(WoodLabel);
                repaint();

            }

        });
        PillowLabel.addMouseListener(new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent e) {
                Xx = e.getX();
                Yy = e.getY();
            }

        });

        PillowLabel.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {

                int x = e.getXOnScreen();
                int y = e.getYOnScreen();
                int SumX = x - Xx - 298;

                if (SumX < 0) {

                } else if (SumX > 300) {

                } else {
                    PillowLabel.setLocation(x - Xx - 298, 400);
                }

            }

        });

        MusicBoxLabel.addMouseListener(new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent e) {
                setVisible(false);
                Pianopuzzle.Open();

            }

        });
        TVLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
            setVisible(false);
            TVpuzzle.Open();
                
            }

        });
        DoorExitLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
            setVisible(false);
            Doorexit.Open();
            }

        });
        
        TabeLabel.addMouseListener(new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent e) {
                if (Tapelost == true) {
                    TabeLabel.setIcon(null);
                    player.getItem(1).setIcon(null);
                }

            }

        });
        KitchenRoomLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {

                setVisible(false);
              
                player.getBathRoom().Open();

            }

        });
         BedRoomLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {

                setVisible(false);
               player.getBedRoom().Open();

            }

        }); 

        player.getRadio(1).addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == 1) {
                    Tapelost = true;

                } else {
                    
                    Tapelost = false;
                }
            }

        });
        player.getRadio(2).addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == 1) {
                    openDrawer = true;

                } else {
                    openDrawer = false;
                    
                }

            }

        });

    }

    public void addPuzzle() {

        Pianopuzzle = new Musicpuzzle(player);
        TVpuzzle = new TV(player);
        Doorexit = new DoorExit(player);
    }

    public Player getplayer() {
        return player;
    }

    public static void main(String args[]) {

        Player Player1 = new Player("Pete");
        Player1.getLivingRoom().Open();

    }
}
// Auxiliary class to resize image

class Musicpuzzle extends OurFrame {

    //private LivingRoom LVR;
    private JLabel MusicpianoLabel, BackLabel, ButtonLabel, NoteArea, KeypuzzleLabel;
    private ImageSet backgroundImg, MusicBoxImg, BacktImg, KeypuzzleImg, LockpuzzleImg, ButtonImg;
    private SoundEffect[] pianosound;
    private SoundEffect twinklesound;
    private String note = "";
    private boolean firsttimefocus, unlock, pickup;

    public Musicpuzzle(Player P) {
        super("Puzzle Music", P);
        //player = P;

        firsttimefocus = false;
        pickup = false;
        contentpane.setLayout(new BorderLayout());
        contentpane.setBackground(Color.DARK_GRAY);

        addcomponent();
    }

    public void addcomponent() {
        Font f = new Font("SanSerif", Font.BOLD, 20);
        MusicBoxImg = new ImageSet("resource/piano.jpg");
        BacktImg = new ImageSet("resource/back.png");
        ButtonImg = new ImageSet("resource/back.png");
        LockpuzzleImg = new ImageSet("resource/Drawer_close.png").resize(626, 100);
        KeypuzzleImg = new ImageSet("resource/key.png").resize(626, 100);

        drawpane = new JLabel();
        drawpane.setLayout(null);

        MusicpianoLabel = new JLabel(MusicBoxImg);
        MusicpianoLabel.setBounds(400, 100, 626, 397);
        MusicpianoLabel.setFocusable(true);

        BackLabel = new JLabel(BacktImg);
        BackLabel.setBounds(0, 0, 64, 64);

        ButtonLabel = new JLabel(ButtonImg);
        ButtonLabel.setBounds(1100, 100, 64, 64);

        KeypuzzleLabel = new JLabel(LockpuzzleImg);
        KeypuzzleLabel.setBounds(400, 0, 626, 100);

        NoteArea = new JLabel();
        NoteArea.setForeground(Color.WHITE);
        NoteArea.setFont(f);
        NoteArea.setBounds(150, 100, 120, 30);

        addListener();
        addmusic();

        drawpane.add(MusicpianoLabel);
        drawpane.add(BackLabel);
        drawpane.add(NoteArea);
        drawpane.add(ButtonLabel);
        drawpane.add(KeypuzzleLabel);

        contentpane.add(drawpane, BorderLayout.CENTER);

        validate();

    }

    public void addListener() {
        addKeyListener(new KeyAdapter() {

            public void keyPressed(KeyEvent e) {
                System.out.print("hello");
                if (e.getKeyCode() == KeyEvent.VK_T) {

                    note += "T";
                    pianosound[0].stop();
                    pianosound[0].playOnce();

                }

                if (e.getKeyCode() == KeyEvent.VK_O) {
                    note += "O";
                    pianosound[4].stop();
                    pianosound[4].playOnce();
                }
                if (e.getKeyCode() == KeyEvent.VK_P) {
                    note += "P";
                    pianosound[5].stop();
                    pianosound[5].playOnce();
                }
                if (e.getKeyCode() == KeyEvent.VK_I) {
                    note += "I";
                    pianosound[3].stop();
                    pianosound[3].playOnce();
                }
                if (e.getKeyCode() == KeyEvent.VK_U) {
                    note += "U";
                    pianosound[2].stop();
                    pianosound[2].playOnce();
                }
                if (e.getKeyCode() == KeyEvent.VK_Y) {
                    note += "Y";
                    pianosound[1].stop();
                    pianosound[1].playOnce();
                }
                Notepuzzle();
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }

        });
        ButtonLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
                if (!firsttimefocus) {
                    setFocusable(true);
                    firsttimefocus = true;
                }
                requestFocusInWindow(true);
            }

        });

        BackLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
                setVisible(false);
                player.getLivingRoom().Open();

            }

        });

        KeypuzzleLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
                if (!pickup && unlock) {

                    player.getItem(0).setIcon(null);
                    KeypuzzleLabel.setIcon(null);
                    pickup = true;
                    unlock = false;
                    validate();
                }

            }

        });

    }

    public void addmusic() {

        twinklesound = new SoundEffect("music/twinkle.wav");
        pianosound = new SoundEffect[8];
        pianosound[0] = new SoundEffect("music/Do.wav");
        pianosound[1] = new SoundEffect("music/Re.wav");
        pianosound[2] = new SoundEffect("music/Mi.wav");
        pianosound[3] = new SoundEffect("music/Fa.wav");
        pianosound[4] = new SoundEffect("music/Sol.wav");
        pianosound[5] = new SoundEffect("music/La.wav");
        pianosound[6] = new SoundEffect("music/SI_2.wav");
        pianosound[7] = new SoundEffect("music/Do octave.wav");
    }

    private void Notepuzzle() {
        NoteArea.setText(note);
        if (note.length() == 7) {
            if (note.equals("TTOOPPO")) {
                if (!pickup) {
                    KeypuzzleLabel.setIcon(KeypuzzleImg);
                }

                twinklesound.stop();
                twinklesound.playOnce();

                unlock = true;

                note = "";
            } else {
                //เพิ่มรูปให้เป็นสีแดงว่าไม่ผ่าน
                note = "";
            }

        }

    }

}

class TV extends OurFrame {

    private JLabel TVLabel, TVnextLabel, TVbackLabel, TVpicture, BackLabel;
    private int ChannelPicture = 0;
    private ImageSet[] picture;
    private ImageSet BackImg;

    public TV(Player p) {
        super("TV Channel", p);

        contentpane.setLayout(new BorderLayout());
        contentpane.setBackground(Color.DARK_GRAY);
        addcomponent();

    }


    public void addcomponent() {

        picture = new ImageSet[3];
        picture[0] = new ImageSet("resource/logo.png").resize(500, 300);
        picture[1] = new ImageSet("resource/test.jpg").resize(500, 300);
        picture[2] = new ImageSet("resource/musicbox.jpg").resize(500, 300);
        BackImg = new ImageSet("resource/back.png");

        drawpane = new JLabel();
        drawpane.setLayout(null);

        TVpicture = new JLabel(picture[0]);
        TVpicture.setBounds(400, 100, 500, 300);

        TVLabel = new JLabel(new ImageSet("resource/TV.png"));
        TVLabel.setBounds(0, 0, 694, 429);
        TVLabel.add(TVpicture);

        TVnextLabel = new JLabel(new ImageSet("resource/back.png"));
        TVnextLabel.setBounds(0, 0, 69, 69);

        TVbackLabel = new JLabel(new ImageSet("resource/back.png"));
        TVbackLabel.setBounds(0, 0, 69, 69);

        BackLabel = new JLabel(BackImg);
        BackLabel.setBounds(0, 0, 64, 64);

        addListener();
       
        contentpane.add(TVbackLabel, BorderLayout.LINE_START);
        contentpane.add(TVnextLabel, BorderLayout.LINE_END);
        contentpane.add(TVLabel, BorderLayout.CENTER);
        contentpane.add(BackLabel,BorderLayout.SOUTH);
        validate();
    }

    public void addListener() {
        TVbackLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
                if (ChannelPicture > 0) {
                    --ChannelPicture;
                    TVpicture.setIcon(picture[ChannelPicture]);

                }

            }

        });

        TVnextLabel.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
                if (ChannelPicture < 2) {
                    ++ChannelPicture;
                    TVpicture.setIcon(picture[ChannelPicture]);

                }
            }

        });
        
        BackLabel.addMouseListener(new MouseAdapter(){
          
            
            public void mousePressed(MouseEvent e) {
               player.getLivingRoom().Open();
               setVisible(false);
            }

           
           
        });
        

    }

}
