
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


abstract class OurFrame extends JFrame {

    private int frameWidth = 1366, frameHeight = 768;
    protected JLabel drawpane;
    protected Player player;
    protected JPanel contentpane,Setpane,Playerpane;
    

    public OurFrame(String s,Player p) {
        
        player = p;
        setTitle(s);
        setBounds(50, 50, frameWidth, frameHeight);
        setResizable(false);
        setVisible(false);
        setLocationRelativeTo(null); // set middle Display
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
        contentpane = (JPanel) getContentPane();
        
        //set your Layout in your own constructor class 
        //Example
        /*
        
        contentpane.setLayout(new BorderLayout());
        
        
        
        */

    }
    public void  Open(){
    setVisible(true);
    contentpane.add(player.getPane(),BorderLayout.PAGE_START);
    validate();
 
     
    }
    public void addpuzzle(){ /*add puzzle event*/}
    public void addcomponent() { /* add for your JLabel JPanel */}
    public void addmusic(){/*add music*/}
    public void addListener() { /* add your Event */}
}
